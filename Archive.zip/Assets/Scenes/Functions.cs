using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Functions : MonoBehaviour
{
    float resultat;
    // Start is called before the first frame update
    void Start()
    {
        Sum(3,4);
        resultat = Sum(3, 4);
        Debug.Log(resultat);
        Prod(7,8);
        resultat = Prod(7, 8);
        Debug.Log(resultat);
        Div(15,8);
        resultat = Div(15, 8);
        Debug.Log(resultat);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    float Sum(float x,float y)
    {
        float z = x + y;
        return z;
    }   
    float  Prod(float x,float y)
    {
        float z = x * y;
        return z;
    }     
    float Div(float x,float y)
    {
        float z = x / y;
        return z;
    }



}
